#!/usr/bin/env python3
import argparse
import os
import sys

CUR_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(CUR_DIR)
sys.path.insert(0, ROOT)

from analyze_blast import main as analyze_main  # reuse existing implementation


def run():
    parser = argparse.ArgumentParser(description="Run BLAST peptide specificity pipeline")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--reference", required=True)
    parser.add_argument("--species", default="Homo sapiens")
    parser.add_argument("--avoid_positions", default="2,-1")
    parser.add_argument("--inward_positions", default="", help="1-based positions to de-prioritize for specificity (comma-separated)")
    parser.add_argument("--specificity_mode", default="conservative", choices=["conservative", "practical"])
    parser.add_argument("--highlight_mode", default="window", choices=["window", "greedy"]) 
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    # Combine avoid and inward positions (de-prioritize both sets)
    avoid = args.avoid_positions
    if args.inward_positions.strip():
        if avoid.strip():
            avoid = avoid + "," + args.inward_positions
        else:
            avoid = args.inward_positions

    # Build CLI argv for analyze_blast.main
    sys.argv = [
        "analyze_blast.py",
        "--input", args.input,
        "--output", os.path.join(args.output_dir, "blast_alignment.png"),
        "--report", os.path.join(args.output_dir, "blast_specificity.txt"),
        "--reference", args.reference,
        "--species", args.species,
        "--avoid_positions", avoid,
        "--specificity_mode", args.specificity_mode,
        "--highlight_mode", args.highlight_mode,
    ]
    analyze_main()


if __name__ == "__main__":
    run()


