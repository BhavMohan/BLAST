## Peptide BLAST specificity pipeline

This pipeline takes an NCBI "FASTA (aligned clusters)" export and a peptide sequence, filters to the requested species, computes discriminative residues and a minimal window, and renders:

- `blast_alignment.png` — alignment visualization with selected positions highlighted
- `blast_specificity.txt` — report with discriminative positions, minimal window, and recommended X-patterns

### Usage

```bash
python blast_run.py \
  --input "/path/to/Protein Sequence Seqdump.txt" \
  --output_dir "/path/to/output/folder" \
  --reference YOURPEPTIDE \
  --species "Homo sapiens" \
  --avoid_positions "2,-1" \
  --inward_positions "" \
  --specificity_mode conservative \
  --highlight_mode window
```

Arguments:
- `--input`: NCBI FASTA (aligned clusters) file.
- `--output_dir`: folder to save outputs.
- `--reference`: peptide sequence (e.g., `ALHGGWTTK`).
- `--species`: species to include (default `Homo sapiens`).
- `--avoid_positions`: 1-based positions to avoid first (e.g., `2,-1` for P2 and last).
- `--inward_positions`: 1-based positions to de-prioritize for specificity; these are appended to avoid list.
- `--specificity_mode`: `conservative` or `practical`.
- `--highlight_mode`: `window` (minimal contiguous window) or `greedy` (greedy set).

Outputs are written to `--output_dir`.


